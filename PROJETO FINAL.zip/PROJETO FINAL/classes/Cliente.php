<?php

class Cliente{
    private $id;
    private $nome;
    private $email;

    protected const VALOR_ALUGUEL = 6.0;

    public function __construct($id, $nome, $email){
        $this->id = $id;
        $this->nome = $nome;
        $this->email = $email;
    }
    
    public function getId() {return $this->id;}
    public function getNome() {return $this->nome;}
    public function getEmail() {return $this->email;}

    public function getTipo(){
        return "comum";
    }

    
}